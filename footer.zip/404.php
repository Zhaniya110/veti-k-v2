<?php get_header(); ?>
<style>
	.header_contact{
		min-height: 160px;
	}
</style>
<?php get_template_part('template/header', 'contact'); ?>

	<div class="container text-center" style="padding: 100px 0;">
	<h1 style="font-size: 132px;">404</h1>
	<p style="font-size: 18px;">Not page.</p>
</div>

<?php get_footer(); ?>