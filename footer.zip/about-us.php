<?php //Template Name: О нас

get_header() ?>

<?php while (have_posts()) :the_post(); ?>
    <div class="page-about">
        <div class="top">
            <div class="container">
                <div class="section-title">
                    <span class="mouse-parallax"><?php the_title(); ?></span>
                    <span class="mouse-parallax2"><?php the_title(); ?></span>
                </div>
                <a href="#experience" class="scroll button-down"></a>

                <img class="animate" src="<?php echo THEME_URL; ?>image/about-1.png" alt="">
            </div>
        </div>

        <div class="experience" id="experience">
            <div class="container">
                <div class="row">
                    <div class="col col-animate col-5">
                        <img class="animate" src="<?php echo THEME_URL; ?>image/about-2.png" alt="">
                    </div>

                    <div class="col">
                        <div class="text">
                            <?php the_content(); ?>
                        </div>

                        <div class="figures">
                            <div class="row">
                                <div class="col col-6">
                                    <h3>20+</h3>
                                    <p>лет в бизнессе</p>
                                </div>
                                <div class="col col-6">
                                    <h3>120+</h3>
                                    <p>Проектов реализовано</p>
                                </div>
                                <div class="col col-6">
                                    <h3>20+</h3>
                                    <p>лет в бизнессе</p>
                                </div>
                                <div class="col col-6">
                                    <h3>120+</h3>
                                    <p>Проектов реализовано</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="our-team">
            <div class="container">
                <h2>Наша команда</h2>
            </div>

            <div class="slider-our-team">
                <div>
                    <div class="item">
                        <img src="<?php echo THEME_URL; ?>image/team-1.png" alt="">
                        <div class="info">
                            <h3>Арнольд <br>Шварцнегер</h3>
                            <p>CEO</p>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="item">
                        <img src="<?php echo THEME_URL; ?>image/team-2.png" alt="">
                        <div class="info">
                            <h3>Арнольд <br>Шварцнегер</h3>
                            <p>CEO</p>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="item">
                        <img src="<?php echo THEME_URL; ?>image/team-3.png" alt="">
                        <div class="info">
                            <h3>Арнольд <br>Шварцнегер</h3>
                            <p>CEO</p>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="item">
                        <img src="<?php echo THEME_URL; ?>image/team-1.png" alt="">
                        <div class="info">
                            <h3>Арнольд <br>Шварцнегер</h3>
                            <p>CEO</p>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="item">
                        <img src="<?php echo THEME_URL; ?>image/team-2.png" alt="">
                        <div class="info">
                            <h3>Арнольд <br>Шварцнегер</h3>
                            <p>CEO</p>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="item">
                        <img src="<?php echo THEME_URL; ?>image/team-3.png" alt="">
                        <div class="info">
                            <h3>Арнольд <br>Шварцнегер</h3>
                            <p>CEO</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <script>
            $(document).ready(function(){
                $('.slider-our-team').slick({
                    arrows: false,
                    dots: true,
                    infinite: true,
                    slidesToShow: 3,
                    slidesToScroll: 1
                });
            });
        </script>
    </div>
<?php endwhile; ?>

<?php get_footer() ?>
