<?php get_header(); ?>

<?php while ( have_posts() ) :the_post(); ?>
<div class="front-page">
    <div class="top">
        <div class="slider-top">
            <div>
                <div class="item">
                    <div class="section-title">
                        <span>Расширяя возможности</span>
                        <span>и ресурсы</span>
                    </div>
                </div>
            </div>
            <div>
                <div class="item">
                    <div class="section-title">
                        <span>Раскрывая потенциал</span>
                        <span>и резервы</span>
                    </div>
                </div>
            </div>
            <div>
                <div class="item">
                    <div class="section-title">
                        <span>Усиливая мощность</span>
                        <span>и работоспособность</span>
                    </div>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function(){
                $('.slider-top').slick({
                    arrows: false,
                    dots: true,
                    autoplay: true,
                    infinite: false,
                    autoplaySpeed: 7000,
                    speed: 0
                });
            });
        </script>

        <div class="container">
            <div class="row">
                <div class="col col-btn">
                    <a href="#" class="button-down"></a>
                </div>

                <div class="col col-auto col-text">
                    <div class="text">Мы помогаем повысить эффективность бизнеса, усиливая команды, меняя поведение людей, указывая цели каждого, команды и компании</div>
                </div>
            </div>
        </div>
    </div>

    <div class="about">
        <div class="container">
            <div class="row">
                <div class="col col-image">
                    <img src="<?php echo THEME_URL; ?>image/home-about.png" alt="" class="tri">
                </div>

                <div class="col">
                    <div class="text">
                        <?php the_content(); ?>
                    </div>
                </div>
            </div>

            <a href="/about-us/" class="link"><span>О нас</span></a>
        </div>
    </div>

    <div class="what-do">
        <div class="container">
            <h2>Что мы делаем</h2>

            <div class="hand">
                <img src="<?php echo THEME_URL; ?>image/hand.png" alt="" class="bobble">
            </div>
            <div class="hand-text">перетащить для большей информации</div>
        </div>

        <div class="slide-what">
            <div>
                <div class="item">
                    <div class="row align-items-end">
                        <div class="col">
                            <div class="text">
                                <h4>Люди и команды</h4>
                                <p>Усиливаем команды под задачи и потребности компании</p>
                            </div>
                        </div>
                        <div class="col col-auto">
                            <img class="img" src="<?php echo THEME_URL; ?>image/team_what.png" alt="">
                        </div>
                    </div>

                    <svg width="555" height="550" viewBox="0 0 555 550" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M64.8 115.3L441.1 4.60001C511.4 -16.1 574.8 53.3 548.7 122.4L409 492.1C385.5 554.2 305.5 569.8 260.9 521L24.3 262C-20.3 213.1 1.59998 133.9 64.8 115.3Z" fill="#f2f2f2"/>
                    </svg>
                </div>
            </div>
            <div>
                <div class="item">
                    <div class="row align-items-end">
                        <div class="col">
                            <div class="text">
                                <h4>Процессы</h4>
                                <p>Выстраиваем все HR процессы в компании</p>
                            </div>
                        </div>
                        <div class="col col-auto">
                            <img class="img" src="<?php echo THEME_URL; ?>image/team_what.png" alt="">
                        </div>
                    </div>
                    <svg width="555" height="550" viewBox="0 0 555 550" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M64.8 115.3L441.1 4.60001C511.4 -16.1 574.8 53.3 548.7 122.4L409 492.1C385.5 554.2 305.5 569.8 260.9 521L24.3 262C-20.3 213.1 1.59998 133.9 64.8 115.3Z" fill="#f2f2f2"/>
                    </svg>
                </div>
            </div>
            <div>
                <div class="item">
                    <div class="row align-items-end">
                        <div class="col">
                            <div class="text">
                                <h4>Технологии</h4>
                                <p>Усиливаем команды под задачи и потребности компании</p>
                            </div>
                        </div>
                        <div class="col col-auto">
                            <img class="img" src="<?php echo THEME_URL; ?>image/team_what.png" alt="">
                        </div>
                    </div>
                    <svg width="555" height="550" viewBox="0 0 555 550" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M64.8 115.3L441.1 4.60001C511.4 -16.1 574.8 53.3 548.7 122.4L409 492.1C385.5 554.2 305.5 569.8 260.9 521L24.3 262C-20.3 213.1 1.59998 133.9 64.8 115.3Z" fill="#f2f2f2"/>
                    </svg>
                </div>
            </div>
            <div>
                <div class="item">
                    <div class="row align-items-end">
                        <div class="col">
                            <div class="text">
                                <h4>Организации</h4>
                                <p>Усиливаем команды под задачи и потребности компании</p>
                            </div>
                        </div>
                        <div class="col col-auto">
                            <img class="img" src="<?php echo THEME_URL; ?>image/team_what.png" alt="">
                        </div>
                    </div>
                    <svg width="555" height="550" viewBox="0 0 555 550" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M64.8 115.3L441.1 4.60001C511.4 -16.1 574.8 53.3 548.7 122.4L409 492.1C385.5 554.2 305.5 569.8 260.9 521L24.3 262C-20.3 213.1 1.59998 133.9 64.8 115.3Z" fill="#f2f2f2"/>
                    </svg>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function(){
                $('.slide-what').slick({
                    infinite: false,
                    arrows: false,
                    centerPadding: '0',
                    variableWidth: true,
                    centerMode: true
                });
            });
        </script>
    </div>
</div>
<?php endwhile; ?>

<?php get_footer(); ?>