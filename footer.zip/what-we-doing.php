<?php //Template Name: Что мы делаем

get_header() ?>

<?php while (have_posts()) :the_post(); ?>
    <div class="page-what-we-doing">
        <div class="top">
            <div class="container">
                <?php $title = get_field('title'); ?>
                <div class="section-title">
                    <span class="mouse-parallax"><?php echo $title['item_1']; ?></span>
                    <span class="mouse-parallax2"><?php echo $title['item_2']; ?>
                        <i><?php echo $title['item_3']; ?></i>
                        <i><?php echo $title['item_3']; ?></i>
                    </span>
                </div>
            </div>
        </div>

        <div class="info">
            <div class="container">
                <div class="row">
                    <div class="col col-animate col-5">
                        <img class="animate" src="<?php echo THEME_URL; ?>image/what-1.png" alt="">
                    </div>

                    <div class="col col-text">
                        <div class="text">
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="accordion-container">
            <div class="container">
                <div class="accordion">
                    <a href="#" class="accordion-title">Люди и команды<i></i></a>
                    <div class="accordion-content">
                        <div class="item">
                            <div class="row">
                                <div class="col col-5 col-image">
                                    <img src="<?php echo THEME_URL; ?>image/team_what.png" alt="">
                                </div>

                                <div class="col">
                                    <div class="text">
                                        <h3>Усиливаем команды под задачи и потребности компании:</h3>
                                        <ul>
                                            <li>Оценивая потенциал людей и команд</li>
                                            <li>Формируя и настраивая команды</li>
                                            <li>Консультируя в форматах индивидуального и
                                                командного коучинга</li>
                                            <li>Разрабатывая программы развития и вшивая обучение
                                                в процессы изменений</li>
                                            <li>Проводя онлайн исследования вовлеченности
                                                персонала и предлагая как использовать полученные
                                                результаты под задачи клиентов</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="accordion">
                    <a href="#" class="accordion-title">Процессы<i></i></a>
                    <div class="accordion-content">
                    </div>
                </div>

                <div class="accordion">
                    <a href="#" class="accordion-title">Технологии<i></i></a>
                    <div class="accordion-content">
                    </div>
                </div>

                <div class="accordion">
                    <a href="#" class="accordion-title">Организации<i></i></a>
                    <div class="accordion-content">
                    </div>
                </div>
            </div>
        </div>


        <script>
            jQuery(document).ready(function (e) {
                jQuery('.accordion-title').on('click', function () {
                    var $this = jQuery(this);

                    if (!$this.parents('.accordion').hasClass('show')) {
                        jQuery('.accordion').removeClass('show');
                        jQuery('.accordion .accordion-content').slideUp(350);

                        $this.parents('.accordion').toggleClass('show');
                        $this.next('.accordion-content').slideToggle(350);
                    } else {
                        jQuery('.accordion').removeClass('show');
                        jQuery('.accordion .accordion-content').slideUp(350);
                    }

                    return false;
                })
            });
        </script>
    </div>
<?php endwhile; ?>

<?php get_footer() ?>
